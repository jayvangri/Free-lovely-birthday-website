Free lovely birthday surprise — glow-guided edition

UNLOCK: 2111999

To host on GitHub Pages:
1. Open your GitHub Pages repository.
2. Upload / replace the file named index.html from this ZIP.
3. Open the site on your mobile browser.

Everything is inside index.html, including the nine photos and birthday audio.
Buttons gently glow to guide the recipient. Original design and interactions are preserved.

Privacy: Because this is a static public GitHub Pages website, the front-end passcode is not secure access control; photos are available in the public source.
